import{d as T}from"./connection-settings.js";function u(e){return e.contact?.displayName||e.contact?.handle||e.contact?.phone||e.contact?.email||"Unknown lead"}function w(e){return e.type.replace(/_/g," ")}const n=document.querySelector("#app");if(!n)throw new Error("Side panel root was not found.");const b=[{key:"ready",label:"Ready",statuses:["queued"]},{key:"preparing",label:"Preparing",statuses:["in_progress"]},{key:"approval",label:"Needs send approval",statuses:["awaiting_send_approval"]},{key:"blocked",label:"Blocked",statuses:["blocked","failed"]},{key:"done",label:"Done",statuses:["sent","monitoring","cancelled"]}];let m=[],y="ready",o="";n.innerHTML=`
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: #080a0c;
      color: #eef4f8;
      font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    .shell { display: grid; gap: 10px; min-width: 0; padding: 10px; }
    .topbar {
      align-items: center;
      border-bottom: 1px solid #27313a;
      display: flex;
      gap: 10px;
      justify-content: space-between;
      padding-bottom: 10px;
    }
    h1 { font-size: 16px; line-height: 1.2; margin: 0; }
    p { color: #aab5bf; font-size: 12px; line-height: 1.45; margin: 0; }
    .muted { color: #87939f; }
    .status { color: #aab5bf; font-size: 12px; line-height: 1.4; min-height: 18px; }
    .ok { color: #a6ffcf; }
    .error { color: #ff8da0; }
    .grid { display: grid; gap: 9px; }
    .panel {
      background: rgba(255,255,255,0.035);
      border: 1px solid #27313a;
      border-radius: 8px;
      padding: 10px;
    }
    .metrics {
      display: grid;
      gap: 6px;
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }
    .metric {
      background: rgba(255,255,255,0.035);
      border: 1px solid #27313a;
      border-radius: 7px;
      padding: 8px;
    }
    .metric strong { display: block; font-size: 17px; line-height: 1; }
    .metric span { color: #87939f; display: block; font-size: 10px; margin-top: 4px; }
    .tabs { display: flex; flex-wrap: wrap; gap: 6px; padding-bottom: 2px; }
    button, a.button {
      align-items: center;
      background: rgba(32,230,190,0.12);
      border: 1px solid rgba(32,230,190,0.34);
      border-radius: 6px;
      color: #ddfff8;
      cursor: pointer;
      display: inline-flex;
      font: inherit;
      font-size: 12px;
      justify-content: center;
      min-height: 32px;
      padding: 7px 9px;
      text-decoration: none;
      white-space: nowrap;
    }
    button.secondary, a.secondary { background: rgba(255,255,255,0.04); border-color: #34414d; color: #dce6ef; }
    button.tab { color: #b8c3cd; min-height: 30px; }
    button.tab.active { background: rgba(32,230,190,0.16); border-color: rgba(32,230,190,0.44); color: #effffb; }
    button:disabled { cursor: not-allowed; opacity: 0.55; }
    .task-list { display: grid; gap: 6px; max-height: 46vh; min-height: 96px; overflow: auto; padding-right: 2px; }
    .task-row {
      align-items: center;
      background: rgba(255,255,255,0.03);
      border: 1px solid #27313a;
      border-radius: 7px;
      cursor: pointer;
      display: grid;
      gap: 8px;
      grid-template-columns: minmax(0, 1fr) auto;
      min-height: 54px;
      padding: 8px 9px;
      text-align: left;
      width: 100%;
      white-space: normal;
    }
    .task-row:hover { background: rgba(255,255,255,0.055); }
    .task-row.selected { background: rgba(32,230,190,0.08); border-color: rgba(32,230,190,0.58); }
    .task-main { display: grid; gap: 4px; min-width: 0; }
    .task-head { align-items: flex-start; display: flex; gap: 8px; justify-content: space-between; min-width: 0; }
    .title { color: #fff; font-size: 12.5px; font-weight: 750; line-height: 1.2; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .meta { color: #87939f; font-size: 9px; line-height: 1.25; overflow: hidden; text-overflow: ellipsis; text-transform: uppercase; white-space: nowrap; }
    .pill {
      border: 1px solid #34414d;
      border-radius: 999px;
      color: #b6c0ca;
      flex: 0 0 auto;
      font-size: 10px;
      padding: 3px 7px;
      text-transform: uppercase;
    }
    .pill.queued, .pill.in_progress { border-color: rgba(32,230,190,0.35); color: #d8fff6; }
    .pill.awaiting_send_approval { border-color: rgba(255,190,80,0.45); color: #ffe1a6; }
    .pill.blocked, .pill.failed { border-color: rgba(255,120,140,0.45); color: #ffc2cb; }
    .detail { display: grid; gap: 8px; }
    .detail h2 { font-size: 14px; line-height: 1.25; margin: 0; }
    .draft {
      background: rgba(0,0,0,0.22);
      border: 1px solid #27313a;
      border-radius: 7px;
      color: #f2f8fc;
      font-size: 12px;
      line-height: 1.5;
      margin: 0;
      max-height: 150px;
      overflow: auto;
      padding: 9px;
      white-space: pre-wrap;
    }
    .actions { display: flex; flex-wrap: wrap; gap: 7px; }
    label { color: #87939f; display: grid; font-size: 10px; gap: 5px; text-transform: uppercase; }
    input {
      background: rgba(255,255,255,0.04);
      border: 1px solid #27313a;
      border-radius: 6px;
      color: #fff;
      font: inherit;
      min-height: 34px;
      outline: none;
      padding: 7px 8px;
      text-transform: none;
      width: 100%;
    }
    .row { align-items: center; display: flex; gap: 8px; justify-content: space-between; }
    .toggle { align-items: center; display: flex; gap: 8px; text-transform: none; }
    .settings summary {
      color: #dce6ef;
      cursor: pointer;
      font-size: 12px;
      font-weight: 700;
      list-style: none;
    }
    .settings summary::-webkit-details-marker { display: none; }
    .settings summary::after {
      color: #87939f;
      content: "Open";
      float: right;
      font-size: 10px;
      font-weight: 500;
      text-transform: uppercase;
    }
    .settings[open] summary::after { content: "Close"; }
    .settings-grid { display: grid; gap: 9px; margin-top: 10px; }
  </style>
  <section class="shell">
    <div class="topbar">
      <div>
        <h1>Leadsy Worker</h1>
        <p>Queue, prepare, approve send, report.</p>
      </div>
      <button class="secondary" id="refresh-tasks" type="button">Refresh</button>
    </div>

    <section class="metrics" id="metrics"></section>
    <div class="status" id="status"></div>

    <section class="panel grid">
      <div class="tabs" id="filters"></div>
      <div class="task-list" id="task-list">Connect Leadsy to load worker tasks.</div>
    </section>

    <section class="panel detail" id="task-detail">
      <p>Select a task to inspect the draft, target, and worker action.</p>
    </section>

    <details class="panel settings" id="settings-panel">
      <summary>Connection settings</summary>
      <form class="settings-grid" id="settings-form">
        <label>
          Leadsy URL
          <input id="base-url" name="baseUrl" autocomplete="off" />
        </label>
        <label>
          Extension token
          <input id="token" name="token" autocomplete="off" type="password" />
        </label>
        <label class="toggle">
          <input id="fallback" name="fallback" type="checkbox" />
          Use OpenRouter fallback if Leadsy is offline
        </label>
        <div class="row">
          <button type="submit">Save</button>
          <button class="secondary" id="check" type="button">Check</button>
        </div>
        <a class="button secondary" href="http://localhost:3000/app/extension" target="_blank" rel="noreferrer">Open Leadsy</a>
      </form>
    </details>
  </section>
`;const E=n.querySelector("#settings-form"),$=n.querySelector("#base-url"),S=n.querySelector("#token"),L=n.querySelector("#fallback"),x=n.querySelector("#status"),z=n.querySelector("#check"),p=n.querySelector("#task-list"),c=n.querySelector("#task-detail"),_=n.querySelector("#refresh-tasks"),U=n.querySelector("#metrics"),k=n.querySelector("#filters");R();E.addEventListener("submit",e=>{e.preventDefault(),q()});z.addEventListener("click",()=>{M()});_.addEventListener("click",()=>{l()});async function R(){const e=await d({type:"leadsy:getSettings"});$.value=e.baseUrl||T.baseUrl,S.value=e.token,L.checked=e.fallbackEnabled,C(),f([]),e.token&&await l()}async function q(){const e={baseUrl:$.value,token:S.value,fallbackEnabled:L.checked};await d({type:"leadsy:saveSettings",settings:e}),s("Saved. Refresh tasks to pull the latest queue.","ok")}async function M(){try{await q();const e=await d({type:"leadsy:getContext"});s(`Connected as ${e.tokenLabel}. ${e.leadCount} leads, ${e.conversationCount} conversations.`,"ok"),await l()}catch(e){s(e instanceof Error?e.message:"Could not connect to Leadsy.","error")}}async function l(){try{const e=await d({type:"leadsy:getTasks"});m=e,(!o||!e.some(t=>t.id===o))&&(o=e[0]?.id||""),f(e),s(`Loaded ${e.length} worker tasks.`,"ok")}catch(e){p.textContent=e instanceof Error?e.message:"Could not load tasks.",s("Task refresh failed.","error")}}function C(){k.innerHTML=b.map(e=>`<button class="tab ${e.key===y?"active":""}" type="button" data-filter="${e.key}">${e.label}</button>`).join("");for(const e of Array.from(k.querySelectorAll("[data-filter]")))e.addEventListener("click",()=>{y=e.dataset.filter||"ready",C(),f(m)})}function f(e){A(e);const t=b.find(r=>r.key===y)||b[0],i=e.filter(r=>t.statuses.includes(r.status));if(!i.length){p.textContent=e.length?"No tasks in this lane.":"No worker tasks yet.",v(e.find(r=>r.id===o));return}i.some(r=>r.id===o)||(o=i[0].id),p.innerHTML=i.map(H).join("");for(const r of Array.from(p.querySelectorAll("[data-task-select]")))r.addEventListener("click",()=>{o=r.dataset.taskSelect||o,f(m)});v(e.find(r=>r.id===o))}function A(e){const t=g(e,["queued"]),i=g(e,["awaiting_send_approval"]),r=g(e,["blocked","failed"]);U.innerHTML=`
    <div class="metric"><strong>${t}</strong><span>Ready</span></div>
    <div class="metric"><strong>${i}</strong><span>Approve send</span></div>
    <div class="metric"><strong>${r}</strong><span>Blocked</span></div>
  `}function H(e){return`
    <button class="task-row${e.id===o?" selected":""}" type="button" data-task-select="${a(e.id)}">
      <span class="task-main">
        <span class="title">${a(u(e))}</span>
        <span class="meta">${a(w(e))} - ${a(e.platform.replace(/-/g," "))} - ${a(e.priority)}</span>
      </span>
      <span class="pill ${a(e.status)}">${a(h(e.status))}</span>
    </button>
  `}function v(e){if(!e){c.innerHTML="<p>Select a task to inspect the draft, target, and worker action.</p>";return}c.innerHTML=`
    <div class="task-head">
      <h2>${a(u(e))}</h2>
      <span class="pill ${a(e.status)}">${a(h(e.status))}</span>
    </div>
    <p class="meta">${a(w(e))} - ${a(e.platform.replace(/-/g," "))}</p>
    <p>${a(e.contextSummary)}</p>
    <p class="draft">${a(e.draftMessage)}</p>
    ${e.targetUrl?`<p class="muted">${a(e.targetUrl)}</p>`:'<p class="muted">No target URL. This will be blocked when run.</p>'}
    ${e.resultSummary?`<p class="muted">${a(e.resultSummary)}</p>`:""}
    <div class="actions">${j(e)}</div>
  `,c.querySelector("[data-task-open]")?.addEventListener("click",()=>{N(e.id)}),c.querySelector("[data-task-approve-send]")?.addEventListener("click",()=>{B(e.id)})}function j(e){return e.status==="queued"||e.status==="in_progress"?`<button type="button" data-task-open="${a(e.id)}">${e.status==="queued"?"Run task":"Reopen task"}</button>`:e.status==="awaiting_send_approval"?`<button type="button" data-task-approve-send="${a(e.id)}">Approve send</button>`:e.status==="blocked"||e.status==="failed"?`<button class="secondary" type="button" disabled>${a(e.blockedReason||e.status)}</button>`:`<button class="secondary" type="button" disabled>${a(h(e.status))}</button>`}async function N(e){if(e)try{const t=await d({type:"leadsy:openTask",taskId:e});s(`Opened ${u(t)}. Prepare the draft in the chat tab.`,"ok"),await l()}catch(t){s(t instanceof Error?t.message:"Could not open task.","error"),await l()}}async function B(e){if(e)try{const t=await d({type:"leadsy:approveTaskSend",taskId:e});s(`Send approved for ${u(t)}.`,"ok"),await l()}catch(t){s(t instanceof Error?t.message:"Could not approve send.","error")}}function g(e,t){return e.filter(i=>t.includes(i.status)).length}function h(e){return e.replace(/_/g," ")}function s(e,t){x.textContent=e,x.className=`status ${t}`}function a(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}async function d(e){const t=await chrome.runtime.sendMessage(e);if(!t?.ok)throw new Error(t?.error||"Leadsy worker did not respond.");return t.value}
//# sourceMappingURL=sidePanel.js.map
