import{d as A}from"./connection-settings.js";function h(e){return e.contact?.displayName||e.contact?.handle||e.contact?.phone||e.contact?.email||"Unknown lead"}function T(e){return e.type.replace(/_/g," ")}const s=document.querySelector("#app");if(!s)throw new Error("Side panel root was not found.");const x=[{key:"ready",label:"Ready",statuses:["queued"]},{key:"preparing",label:"Preparing",statuses:["in_progress"]},{key:"approval",label:"Waiting on Leadsy",statuses:["awaiting_send_approval"]},{key:"blocked",label:"Blocked",statuses:["postponed","blocked","failed"]},{key:"done",label:"Done",statuses:["sent","monitoring","cancelled"]}];let l=[],k="ready",i="";const o=new Set;s.innerHTML=`
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: #080a0c;
      color: #eef4f8;
      font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    .shell { display: grid; gap: 10px; min-width: 0; padding: 10px; }
    .topbar {
      align-items: center;
      border-bottom: 1px solid #27313a;
      display: flex;
      gap: 10px;
      justify-content: space-between;
      padding-bottom: 10px;
    }
    h1 { font-size: 16px; line-height: 1.2; margin: 0; }
    p { color: #aab5bf; font-size: 12px; line-height: 1.45; margin: 0; }
    .muted { color: #87939f; }
    .status { color: #aab5bf; font-size: 12px; line-height: 1.4; min-height: 18px; }
    .ok { color: #a6ffcf; }
    .error { color: #ff8da0; }
    .grid { display: grid; gap: 9px; }
    .panel {
      background: rgba(255,255,255,0.035);
      border: 1px solid #27313a;
      border-radius: 8px;
      padding: 10px;
    }
    .metrics {
      display: grid;
      gap: 6px;
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }
    .metric {
      background: rgba(255,255,255,0.035);
      border: 1px solid #27313a;
      border-radius: 7px;
      padding: 8px;
    }
    .metric strong { display: block; font-size: 17px; line-height: 1; }
    .metric span { color: #87939f; display: block; font-size: 10px; margin-top: 4px; }
    .tabs { display: flex; flex-wrap: wrap; gap: 6px; padding-bottom: 2px; }
    .batch-controls { align-items: center; display: flex; flex-wrap: wrap; gap: 6px; }
    .batch-summary { color: #aab5bf; font-size: 11px; line-height: 1.4; min-height: 16px; }
    button, a.button {
      align-items: center;
      background: rgba(32,230,190,0.12);
      border: 1px solid rgba(32,230,190,0.34);
      border-radius: 6px;
      color: #ddfff8;
      cursor: pointer;
      display: inline-flex;
      font: inherit;
      font-size: 12px;
      justify-content: center;
      min-height: 32px;
      padding: 7px 9px;
      text-decoration: none;
      white-space: nowrap;
    }
    button.secondary, a.secondary { background: rgba(255,255,255,0.04); border-color: #34414d; color: #dce6ef; }
    button.tab { color: #b8c3cd; min-height: 30px; }
    button.tab.active { background: rgba(32,230,190,0.16); border-color: rgba(32,230,190,0.44); color: #effffb; }
    button:disabled { cursor: not-allowed; opacity: 0.55; }
    .task-list { display: grid; gap: 6px; max-height: 46vh; min-height: 96px; overflow: auto; padding-right: 2px; }
    .task-row {
      align-items: center;
      background: rgba(255,255,255,0.03);
      border: 1px solid #27313a;
      border-radius: 7px;
      cursor: pointer;
      display: grid;
      gap: 8px;
      grid-template-columns: auto minmax(0, 1fr) auto;
      min-height: 54px;
      padding: 8px 9px;
      text-align: left;
      width: 100%;
      white-space: normal;
    }
    .task-row:hover { background: rgba(255,255,255,0.055); }
    .task-row.selected { background: rgba(32,230,190,0.08); border-color: rgba(32,230,190,0.58); }
    .task-row input[type="checkbox"] { height: 16px; min-height: 16px; padding: 0; width: 16px; }
    .task-select-button {
      background: transparent;
      border: 0;
      justify-content: flex-start;
      min-height: 0;
      padding: 0;
      text-align: left;
      white-space: normal;
    }
    .task-main { display: grid; gap: 4px; min-width: 0; }
    .task-head { align-items: flex-start; display: flex; gap: 8px; justify-content: space-between; min-width: 0; }
    .title { color: #fff; font-size: 12.5px; font-weight: 750; line-height: 1.2; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .meta { color: #87939f; font-size: 9px; line-height: 1.25; overflow: hidden; text-overflow: ellipsis; text-transform: uppercase; white-space: nowrap; }
    .pill {
      border: 1px solid #34414d;
      border-radius: 999px;
      color: #b6c0ca;
      flex: 0 0 auto;
      font-size: 10px;
      padding: 3px 7px;
      text-transform: uppercase;
    }
    .pill.queued, .pill.in_progress { border-color: rgba(32,230,190,0.35); color: #d8fff6; }
    .pill.awaiting_send_approval { border-color: rgba(255,190,80,0.45); color: #ffe1a6; }
    .pill.blocked, .pill.failed { border-color: rgba(255,120,140,0.45); color: #ffc2cb; }
    .detail { display: grid; gap: 8px; }
    .detail h2 { font-size: 14px; line-height: 1.25; margin: 0; }
    .draft {
      background: rgba(0,0,0,0.22);
      border: 1px solid #27313a;
      border-radius: 7px;
      color: #f2f8fc;
      font-size: 12px;
      line-height: 1.5;
      margin: 0;
      max-height: 150px;
      overflow: auto;
      padding: 9px;
      white-space: pre-wrap;
    }
    .actions { display: flex; flex-wrap: wrap; gap: 7px; }
    label { color: #87939f; display: grid; font-size: 10px; gap: 5px; text-transform: uppercase; }
    input {
      background: rgba(255,255,255,0.04);
      border: 1px solid #27313a;
      border-radius: 6px;
      color: #fff;
      font: inherit;
      min-height: 34px;
      outline: none;
      padding: 7px 8px;
      text-transform: none;
      width: 100%;
    }
    .row { align-items: center; display: flex; gap: 8px; justify-content: space-between; }
    .toggle { align-items: center; display: flex; gap: 8px; text-transform: none; }
    .settings summary {
      color: #dce6ef;
      cursor: pointer;
      font-size: 12px;
      font-weight: 700;
      list-style: none;
    }
    .settings summary::-webkit-details-marker { display: none; }
    .settings summary::after {
      color: #87939f;
      content: "Open";
      float: right;
      font-size: 10px;
      font-weight: 500;
      text-transform: uppercase;
    }
    .settings[open] summary::after { content: "Close"; }
    .settings-grid { display: grid; gap: 9px; margin-top: 10px; }
  </style>
  <section class="shell">
    <div class="topbar">
      <div>
        <h1>Leadsy Worker</h1>
        <p>Queue, prepare, wait for Leadsy, report.</p>
      </div>
      <button class="secondary" id="refresh-tasks" type="button">Refresh</button>
    </div>

    <section class="metrics" id="metrics"></section>
    <div class="status" id="status"></div>
    <section class="panel grid">
      <div class="batch-controls">
        <button id="run-selected" type="button">Run selected tasks</button>
        <button class="secondary" id="select-visible" type="button">Select all visible</button>
        <button class="secondary" id="clear-selection" type="button">Clear selection</button>
      </div>
      <div class="batch-summary" id="batch-summary">No tasks selected.</div>
    </section>

    <section class="panel grid">
      <div class="tabs" id="filters"></div>
      <div class="task-list" id="task-list">Connect Leadsy to load worker tasks.</div>
    </section>

    <section class="panel detail" id="task-detail">
      <p>Select a task to inspect the draft, target, and worker action.</p>
    </section>

    <details class="panel settings" id="settings-panel">
      <summary>Connection settings</summary>
      <form class="settings-grid" id="settings-form">
        <label>
          Leadsy URL
          <input id="base-url" name="baseUrl" autocomplete="off" />
        </label>
        <label>
          Extension token
          <input id="token" name="token" autocomplete="off" type="password" />
        </label>
        <label class="toggle">
          <input id="fallback" name="fallback" type="checkbox" />
          Use OpenRouter fallback if Leadsy is offline
        </label>
        <div class="row">
          <button type="submit">Save</button>
          <button class="secondary" id="check" type="button">Check</button>
        </div>
        <a class="button secondary" href="http://localhost:3000/app/extension" target="_blank" rel="noreferrer">Open Leadsy</a>
      </form>
    </details>
  </section>
`;const M=s.querySelector("#settings-form"),E=s.querySelector("#base-url"),z=s.querySelector("#token"),R=s.querySelector("#fallback"),L=s.querySelector("#status"),j=s.querySelector("#check"),g=s.querySelector("#task-list"),y=s.querySelector("#task-detail"),F=s.querySelector("#refresh-tasks"),H=s.querySelector("#metrics"),q=s.querySelector("#filters"),v=s.querySelector("#run-selected"),N=s.querySelector("#select-visible"),D=s.querySelector("#clear-selection"),O=s.querySelector("#batch-summary");K();M.addEventListener("submit",e=>{e.preventDefault(),U()});j.addEventListener("click",()=>{P()});F.addEventListener("click",()=>{d()});v.addEventListener("click",()=>{G()});N.addEventListener("click",()=>{const e=new Set(l.filter(t=>o.has(t.id)).map(w));for(const t of B()){const a=w(t);S(t)&&!e.has(a)&&(o.add(t.id),e.add(a))}u(l)});D.addEventListener("click",()=>{o.clear(),u(l)});async function K(){const e=await f({type:"leadsy:getSettings"});E.value=e.baseUrl||A.baseUrl,z.value=e.token,R.checked=e.fallbackEnabled,_(),u([]),e.token&&await d()}async function U(){const e={baseUrl:E.value,token:z.value,fallbackEnabled:R.checked};await f({type:"leadsy:saveSettings",settings:e}),c("Saved. Refresh tasks to pull the latest queue.","ok")}async function P(){try{await U();const e=await f({type:"leadsy:getContext"});c(`Connected as ${e.tokenLabel}. ${e.leadCount} leads, ${e.conversationCount} conversations.`,"ok"),await d()}catch(e){c(e instanceof Error?e.message:"Could not connect to Leadsy.","error")}}async function d(){try{const e=await f({type:"leadsy:getTasks"});l=e,(!i||!e.some(t=>t.id===i))&&(i=e[0]?.id||""),u(e),c(`Loaded ${e.length} worker tasks.`,"ok")}catch(e){g.textContent=e instanceof Error?e.message:"Could not load tasks.",c("Task refresh failed.","error")}}function _(){q.innerHTML=x.map(e=>`<button class="tab ${e.key===k?"active":""}" type="button" data-filter="${e.key}">${e.label}</button>`).join("");for(const e of Array.from(q.querySelectorAll("[data-filter]")))e.addEventListener("click",()=>{k=e.dataset.filter||"ready",_(),u(l)})}function u(e){Q(e);const t=B();for(const a of[...o])e.some(r=>r.id===a)||o.delete(a);if(p(),!t.length){g.textContent=e.length?"No tasks in this lane.":"No worker tasks yet.",C(e.find(a=>a.id===i));return}t.some(a=>a.id===i)||(i=t[0].id),g.innerHTML=t.map(V).join("");for(const a of Array.from(g.querySelectorAll("[data-task-checkbox]")))a.addEventListener("change",()=>{const r=a.dataset.taskId||"";r&&(a.checked?o.add(r):o.delete(r),p())});for(const a of Array.from(g.querySelectorAll("[data-task-select]")))a.addEventListener("click",()=>{i=a.dataset.taskSelect||i,u(l)});C(e.find(a=>a.id===i))}function B(){const e=x.find(t=>t.key===k)||x[0];return l.filter(t=>e.statuses.includes(t.status))}function S(e){return e.status==="queued"||e.status==="approved"||e.status==="postponed"}function I(e){const t=new Set;return e.filter(a=>{if(!S(a))return!1;const r=w(a);return t.has(r)?!1:(t.add(r),!0)})}function w(e){return W(e.targetUrl)||[e.platform,b(e.contact?.phone),b(e.contact?.email),b(e.contact?.handle),b(e.contact?.profileUrl),b(e.contact?.displayName)].filter(Boolean).join(":")||e.id}function W(e){if(!e)return"";try{const t=new URL(e);if(t.hash="",t.hostname==="web.whatsapp.com"){const a=t.searchParams.get("phone")?.replace(/[^\d]/g,"");if(a)return`whatsapp:${a}`}return t.toString().toLowerCase()}catch{return e.trim().toLowerCase()}}function b(e){return e?.trim().toLowerCase().replace(/\s+/g," ")}function p(e){const t=l.filter(r=>o.has(r.id)),a=I(t);v.disabled=!a.length,O.textContent=e||`${o.size} selected, ${a.length} ready to run.`}function Q(e){const t=m(e,["queued"]),a=m(e,["awaiting_send_approval"]),r=m(e,["blocked","failed"]);H.innerHTML=`
    <div class="metric"><strong>${t}</strong><span>Ready</span></div>
    <div class="metric"><strong>${a}</strong><span>App approval</span></div>
    <div class="metric"><strong>${r}</strong><span>Blocked</span></div>
  `}function V(e){const t=e.id===i?" selected":"",a=o.has(e.id)?"checked":"",r=S(e)?"":"disabled";return`
    <div class="task-row${t}">
      <input type="checkbox" data-task-checkbox data-task-id="${n(e.id)}" ${a} ${r} aria-label="Select ${n(h(e))}" />
      <button class="task-select-button" type="button" data-task-select="${n(e.id)}">
      <span class="task-main">
        <span class="title">${n(h(e))}</span>
        <span class="meta">${n(T(e))} - ${n(e.platform.replace(/-/g," "))} - ${n(e.priority)}</span>
      </span>
      </button>
      <span class="pill ${n(e.status)}">${n($(e.status))}</span>
    </div>
  `}function C(e){if(!e){y.innerHTML="<p>Select a task to inspect the draft, target, and worker action.</p>";return}y.innerHTML=`
    <div class="task-head">
      <h2>${n(h(e))}</h2>
      <span class="pill ${n(e.status)}">${n($(e.status))}</span>
    </div>
    <p class="meta">${n(T(e))} - ${n(e.platform.replace(/-/g," "))}</p>
    <p>${n(e.contextSummary)}</p>
    <p class="draft">${n(e.draftMessage)}</p>
    ${e.targetUrl?`<p class="muted">${n(e.targetUrl)}</p>`:'<p class="muted">No target URL. This will be blocked when run.</p>'}
    ${e.resultSummary?`<p class="muted">${n(e.resultSummary)}</p>`:""}
    <div class="actions">${J(e)}</div>
  `,y.querySelector("[data-task-open]")?.addEventListener("click",()=>{X(e.id)})}async function G(){const e=I(l.filter(t=>o.has(t.id))).map(t=>t.id);if(!e.length){p("Select at least one ready task.");return}v.disabled=!0,p(`Running ${e.length} selected tasks...`);try{const t=await f({type:"leadsy:runSelectedTasks",taskIds:e});o.clear(),c(`Batch ${t.batchRunId} finished. ${t.requested} requested, ${t.failed} failed.`,"ok"),p(`Finished ${t.requested} selected tasks. Failed: ${t.failed}.`),await d()}catch(t){c(t instanceof Error?t.message:"Could not run selected tasks.","error"),p("Selected batch stopped. Check blocked tasks and retry."),await d()}}function J(e){return e.status==="queued"||e.status==="in_progress"?`<button type="button" data-task-open="${n(e.id)}">${e.status==="queued"?"Run task":"Reopen task"}</button>`:e.status==="awaiting_send_approval"?'<button class="secondary" type="button" disabled>Waiting for Leadsy app</button>':e.status==="blocked"||e.status==="failed"?`<button class="secondary" type="button" disabled>${n(e.blockedReason||e.status)}</button>`:`<button class="secondary" type="button" disabled>${n($(e.status))}</button>`}async function X(e){if(e)try{const t=await f({type:"leadsy:openTask",taskId:e});c(`Opened ${h(t)}. Prepare the draft in the chat tab.`,"ok"),await d()}catch(t){c(t instanceof Error?t.message:"Could not open task.","error"),await d()}}function m(e,t){return e.filter(a=>t.includes(a.status)).length}function $(e){return e.replace(/_/g," ")}function c(e,t){L.textContent=e,L.className=`status ${t}`}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}async function f(e){const t=await chrome.runtime.sendMessage(e);if(!t?.ok)throw new Error(t?.error||"Leadsy worker did not respond.");return t.value}
//# sourceMappingURL=sidePanel.js.map
